Here is a breakdwn of the attributes in the game data:


state: the current state of the table
history: all past states of the current hand

game: game of the table
hand: hand of the table
sb: small blind amount
pot: total amout bet for current hand, amount you could potentially win that hand
buyin: players buyin for the table (can be diffirent per player)
commonCards: the cards on the table accessable to all players
db/hasDB: indicates if that player has the dealer button
callAmount: min amount needed to keep playing the hand
minimumRaiseAmount: min amount needed to raise
players: current players at the table
	chips: total chips available to that player
	chipsBet: chips that player has bet on the current hand
	cards: your cards (only available on your player object)
me: the index of your bot in the players array
